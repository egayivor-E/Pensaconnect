import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/group_chat_model.dart';
import '../services/api_service.dart';

class GroupChatRepository {
  /// Fetch all groups the user belongs to
  Future<List<GroupChat>> getGroups() async {
    try {
      final response = await ApiService.get('group-chats', headers: {});

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data
            .map<GroupChat>(
              (jsonItem) =>
                  GroupChat.fromJson(jsonItem as Map<String, dynamic>),
            )
            .toList();
      } else {
        debugPrint(
          "❌ Failed to load groups: ${response.statusCode} - ${response.body}",
        );
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching groups: $e");
      return [];
    }
  }
}
