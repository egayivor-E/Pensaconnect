import 'dart:async';
import 'package:flutter/material.dart';
import '../repositories/message_repository.dart';
import '../repositories/auth_repository.dart';
import '../models/message_model.dart';

class GroupChatDetailScreen extends StatefulWidget {
  final String groupId;
  final String groupName;

  const GroupChatDetailScreen({
    super.key,
    required this.groupId,
    required this.groupName,
  });

  /// Factory to build from GoRouter extras
  factory GroupChatDetailScreen.fromExtras(Map<String, dynamic> extras) {
    return GroupChatDetailScreen(
      groupId: extras['groupId'] as String,
      groupName: extras['groupName'] as String,
    );
  }

  @override
  State<GroupChatDetailScreen> createState() => _GroupChatDetailScreenState();
}

class _GroupChatDetailScreenState extends State<GroupChatDetailScreen> {
  final MessageRepository _messageRepo = MessageRepository();
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<Message> _messages = [];
  bool _loading = true;
  String? _authToken;
  String? _currentUserId; // ✅ store logged-in user ID
  Timer? _pollingTimer;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    _authToken = await AuthRepository().getToken();
    _currentUserId = await AuthRepository().getCurrentUserId(); // ✅ new helper

    if (_authToken == null || _authToken!.isEmpty) {
      debugPrint("❌ No auth token available. User may need to log in.");
      setState(() {
        _loading = false;
      });
      return;
    }

    await _loadMessages();

    // Poll messages every 5 seconds
    _pollingTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _loadMessages();
    });
  }

  Future<void> _loadMessages() async {
    try {
      final msgs = await _messageRepo.fetchGroupMessages(widget.groupId);

      if (!mounted) return;

      setState(() {
        _messages = msgs;
        _messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
        _loading = false;
      });

      _scrollToBottom();
    } catch (e) {
      debugPrint('❌ Error loading messages: $e');
      if (!mounted) return;
      setState(() {
        _messages = [];
        _loading = false;
      });
    }
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    try {
      final msg = await _messageRepo.sendGroupMessage(widget.groupId, text);

      if (msg == null) return;
      if (!mounted) return;

      setState(() {
        _messages.add(msg);
        _controller.clear();
      });

      _scrollToBottom();
    } catch (e) {
      debugPrint('❌ Error sending message: $e');
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.groupName)),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: _messages.isEmpty
                      ? const Center(child: Text("No messages yet"))
                      : ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.all(16),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final msg = _messages[index];
                            final isMe =
                                msg.senderId == _currentUserId; // ✅ FIX
                            return Align(
                              alignment: isMe
                                  ? Alignment.centerRight
                                  : Alignment.centerLeft,
                              child: Container(
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: isMe
                                      ? Theme.of(
                                          context,
                                        ).colorScheme.primary.withOpacity(0.1)
                                      : Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  "${msg.senderName}: ${msg.content}", // ✅ show name
                                ),
                              ),
                            );
                          },
                        ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _controller,
                            decoration: const InputDecoration(
                              hintText: 'Type a message...',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(24),
                                ),
                              ),
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                            ),
                            onSubmitted: (_) => _sendMessage(),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.send),
                          onPressed: _sendMessage,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
