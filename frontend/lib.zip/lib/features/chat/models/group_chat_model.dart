// lib/models/group_chat_model.dart
class GroupChat {
  final String id;
  final String name;
  final String description;

  GroupChat({required this.id, required this.name, required this.description});

  // Mock from JSON / API
  factory GroupChat.fromJson(Map<String, dynamic> json) {
    return GroupChat(
      id: json['id'],
      name: json['name'],
      description: json['description'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'id': id, 'name': name, 'description': description};
  }
}
