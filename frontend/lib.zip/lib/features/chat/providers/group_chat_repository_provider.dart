import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:app/core/services/api_service_provider.dart';
import 'package:app/features/chat/data/group_chat_repository.dart';

final group_chat_repository_provider = Provider<GroupChatRepository>((ref) {
  final api = ref.watch(apiServiceProvider);
  return GroupChatRepository(api);
});
