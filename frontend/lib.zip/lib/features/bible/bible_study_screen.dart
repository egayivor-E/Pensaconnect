import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'bible_providers.dart';
import 'bible_study_detail_screen.dart';
import 'bible_models.dart';

class BibleStudyScreen extends ConsumerWidget {
  const BibleStudyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final devotions = ref.watch(devotionsProvider);
    final studyPlans = ref.watch(studyPlansProvider);
    final archives = ref.watch(archivesProvider);

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Bible Study"),
          bottom: const TabBar(
            tabs: [
              Tab(text: "Devotions"),
              Tab(text: "Plans"),
              Tab(text: "Archives"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // ---------------- Devotions ----------------
            RefreshIndicator(
              onRefresh: () async {
                ref.refresh(devotionsProvider);
              },
              child: devotions.when(
                data: (list) => ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final devotion = list[i];
                    return ListTile(
                      title: Text(devotion.title),
                      subtitle: Text(devotion.verse),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BibleStudyDetailScreen.devotion(
                              devotionId: devotion.id!,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (err, _) => Center(child: Text("Error: $err")),
              ),
            ),

            // ---------------- Study Plans ----------------
            RefreshIndicator(
              onRefresh: () async {
                ref.refresh(studyPlansProvider);
              },
              child: studyPlans.when(
                data: (list) => ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final plan = list[i];
                    return ListTile(
                      title: Text(plan.title),
                      subtitle: Text(plan.level ?? "Beginner"),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                BibleStudyDetailScreen.plan(planId: plan.id!),
                          ),
                        );
                      },
                    );
                  },
                ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (err, _) => Center(child: Text("Error: $err")),
              ),
            ),

            // ---------------- Archives ----------------
            RefreshIndicator(
              onRefresh: () async {
                ref.refresh(archivesProvider);
              },
              child: archives.when(
                data: (list) => ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final archive = list[i];
                    return ListTile(
                      title: Text(archive.title),
                      subtitle: Text(archive.description ?? ""),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BibleStudyDetailScreen.archive(
                              archiveId: archive.id!,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (err, _) => Center(child: Text("Error: $err")),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
