import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/api_service.dart';
import 'bible_models.dart';

/// Repository handles all Bible Study API calls
class BibleRepository {
  final ApiService api;

  BibleRepository(this.api);

  /// ---------------- Devotions ----------------
  Future<List<Devotion>> getDevotions() async {
    final res = await api.get("bible/devotions");
    final data = jsonDecode(res.body)["data"] as List;
    return data.map((e) => Devotion.fromJson(e)).toList();
  }

  Future<Devotion> getDevotion(int id) async {
    final res = await api.get("bible/devotions/$id");
    final data = jsonDecode(res.body)["data"];
    return Devotion.fromJson(data);
  }

  Future<Devotion> createDevotion(Map<String, dynamic> payload) async {
    final res = await api.post("bible/devotions", payload);
    final data = jsonDecode(res.body)["data"];
    return Devotion.fromJson(data);
  }

  Future<void> deleteDevotion(int id) async {
    await api.delete("bible/devotions/$id");
  }

  /// ---------------- Study Plans ----------------
  Future<List<StudyPlan>> getStudyPlans() async {
    final res = await api.get("bible/plans");
    final data = jsonDecode(res.body)["data"] as List;
    return data.map((e) => StudyPlan.fromJson(e)).toList();
  }

  Future<StudyPlan> getStudyPlan(int id) async {
    final res = await api.get("bible/plans/$id");
    final data = jsonDecode(res.body)["data"];
    return StudyPlan.fromJson(data);
  }

  Future<StudyPlan> createStudyPlan(Map<String, dynamic> payload) async {
    final res = await api.post("bible/plans", payload);
    final data = jsonDecode(res.body)["data"];
    return StudyPlan.fromJson(data);
  }

  Future<void> deleteStudyPlan(int id) async {
    await api.delete("bible/plans/$id");
  }

  /// ---------------- Progress ----------------
  Future<List<StudyPlanProgress>> getProgress(int planId) async {
    final res = await api.get("bible/plans/$planId/progress");
    final data = jsonDecode(res.body)["data"] as List;
    return data.map((e) => StudyPlanProgress.fromJson(e)).toList();
  }

  Future<StudyPlanProgress> updateProgress(
    int planId,
    Map<String, dynamic> payload,
  ) async {
    final res = await api.post("bible/plans/$planId/progress", payload);
    final data = jsonDecode(res.body)["data"];
    return StudyPlanProgress.fromJson(data);
  }

  /// ---------------- Archives ----------------
  Future<List<Archive>> getArchives() async {
    final res = await api.get("bible/archives");
    final data = jsonDecode(res.body)["data"] as List;
    return data.map((e) => Archive.fromJson(e)).toList();
  }

  Future<Archive> createArchive(Map<String, dynamic> payload) async {
    final res = await api.post("bible/archives", payload);
    final data = jsonDecode(res.body)["data"];
    return Archive.fromJson(data);
  }

  Future<void> deleteArchive(int id) async {
    await api.delete("bible/archives/$id");
  }
}

/// ---------------- Riverpod Provider ----------------
final bibleRepositoryProvider = Provider<BibleRepository>((ref) {
  final api = ref.watch(apiServiceProvider);
  return BibleRepository(api);
});
