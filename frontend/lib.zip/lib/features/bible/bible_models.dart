import 'package:freezed_annotation/freezed_annotation.dart';

part 'bible_models.freezed.dart';
part 'bible_models.g.dart';

/// ---------------- Devotion ----------------
@freezed
class Devotion with _$Devotion {
  const factory Devotion({
    int? id,
    required String title,
    required String verse,
    required String content,
    String? reflection,
    String? prayer,
    String? date,
    Author? author,
  }) = _Devotion;

  factory Devotion.fromJson(Map<String, dynamic> json) =>
      _$DevotionFromJson(json);
}

/// ---------------- Study Plan ----------------
@freezed
class StudyPlan with _$StudyPlan {
  const factory StudyPlan({
    int? id,
    required String title,
    String? description,
    String? level,
    int? totalDays,
    bool? isPublic,
    Author? author,
    List<StudyPlanProgress>? progresses,
  }) = _StudyPlan;

  factory StudyPlan.fromJson(Map<String, dynamic> json) =>
      _$StudyPlanFromJson(json);
}

/// ---------------- Study Plan Progress ----------------
@freezed
class StudyPlanProgress with _$StudyPlanProgress {
  const factory StudyPlanProgress({
    int? id,
    required int dayNumber,
    required bool completed,
    User? user,
  }) = _StudyPlanProgress;

  factory StudyPlanProgress.fromJson(Map<String, dynamic> json) =>
      _$StudyPlanProgressFromJson(json);
}

/// ---------------- Archive ----------------
@freezed
class Archive with _$Archive {
  const factory Archive({
    int? id,
    required String title,
    String? description,
    String? date,
    Author? author,
  }) = _Archive;

  factory Archive.fromJson(Map<String, dynamic> json) =>
      _$ArchiveFromJson(json);
}

/// ---------------- Author ----------------
@freezed
class Author with _$Author {
  const factory Author({
    int? id,
    required String username,
    String? fullName,
    String? profilePicture,
  }) = _Author;

  factory Author.fromJson(Map<String, dynamic> json) => _$AuthorFromJson(json);
}

/// ---------------- User ----------------
@freezed
class User with _$User {
  const factory User({
    int? id,
    required String username,
    String? fullName,
    String? profilePicture,
  }) = _User;

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
}
