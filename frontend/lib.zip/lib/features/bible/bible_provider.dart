import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'bible_repository.dart';
import 'bible_models.dart';

/// ---------------- Devotions ----------------
final devotionsProvider = FutureProvider<List<Devotion>>((ref) async {
  final repo = ref.watch(bibleRepositoryProvider);
  return repo.getDevotions();
});

final devotionDetailProvider = FutureProvider.family<Devotion, int>((
  ref,
  devotionId,
) async {
  final repo = ref.watch(bibleRepositoryProvider);
  return repo.getDevotion(devotionId);
});

/// ---------------- Study Plans ----------------
final studyPlansProvider = FutureProvider<List<StudyPlan>>((ref) async {
  final repo = ref.watch(bibleRepositoryProvider);
  return repo.getStudyPlans();
});

final studyPlanDetailProvider = FutureProvider.family<StudyPlan, int>((
  ref,
  planId,
) async {
  final repo = ref.watch(bibleRepositoryProvider);
  return repo.getStudyPlan(planId);
});

/// ---------------- Study Plan Progress ----------------
final studyPlanProgressProvider =
    FutureProvider.family<List<StudyPlanProgress>, int>((ref, planId) async {
      final repo = ref.watch(bibleRepositoryProvider);
      return repo.getProgress(planId);
    });

/// Progress actions (update progress)
class StudyPlanProgressNotifier
    extends StateNotifier<AsyncValue<StudyPlanProgress?>> {
  final BibleRepository repo;
  final int planId;

  StudyPlanProgressNotifier(this.repo, this.planId)
    : super(const AsyncValue.data(null));

  Future<void> updateProgress(Map<String, dynamic> payload) async {
    state = const AsyncValue.loading();
    try {
      final progress = await repo.updateProgress(planId, payload);
      state = AsyncValue.data(progress);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}

final studyPlanProgressNotifierProvider =
    StateNotifierProvider.family<
      StudyPlanProgressNotifier,
      AsyncValue<StudyPlanProgress?>,
      int
    >((ref, planId) {
      final repo = ref.watch(bibleRepositoryProvider);
      return StudyPlanProgressNotifier(repo, planId);
    });

/// ---------------- Archives ----------------
final archivesProvider = FutureProvider<List<Archive>>((ref) async {
  final repo = ref.watch(bibleRepositoryProvider);
  return repo.getArchives();
});

final archiveDetailProvider = FutureProvider.family<Archive, int>((
  ref,
  archiveId,
) async {
  final repo = ref.watch(bibleRepositoryProvider);
  // You can add a dedicated getArchive() in repo if needed
  final archives = await repo.getArchives();
  return archives.firstWhere((a) => a.id == archiveId);
});
