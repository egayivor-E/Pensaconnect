import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'bible_providers.dart';
import 'bible_models.dart';

class BibleStudyDetailScreen extends ConsumerWidget {
  final int? devotionId;
  final int? planId;
  final int? archiveId;

  const BibleStudyDetailScreen._({
    this.devotionId,
    this.planId,
    this.archiveId,
    super.key,
  });

  /// Named constructors for convenience
  factory BibleStudyDetailScreen.devotion({required int devotionId}) {
    return BibleStudyDetailScreen._(devotionId: devotionId);
  }

  factory BibleStudyDetailScreen.plan({required int planId}) {
    return BibleStudyDetailScreen._(planId: planId);
  }

  factory BibleStudyDetailScreen.archive({required int archiveId}) {
    return BibleStudyDetailScreen._(archiveId: archiveId);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (devotionId != null) {
      final devotion = ref.watch(devotionDetailProvider(devotionId!));
      return _buildDetailScreen<Devotion>(
        context,
        devotion,
        titleBuilder: (d) => d.title,
        bodyBuilder: (d) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(d.verse, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Text(d.content),
            if (d.reflection != null) ...[
              const SizedBox(height: 16),
              Text("Reflection", style: Theme.of(context).textTheme.titleLarge),
              Text(d.reflection!),
            ],
            if (d.prayer != null) ...[
              const SizedBox(height: 16),
              Text("Prayer", style: Theme.of(context).textTheme.titleLarge),
              Text(d.prayer!),
            ],
          ],
        ),
      );
    }

    if (planId != null) {
      final plan = ref.watch(studyPlanDetailProvider(planId!));
      return _buildDetailScreen<StudyPlan>(
        context,
        plan,
        titleBuilder: (p) => p.title,
        bodyBuilder: (p) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Level: ${p.level}",
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 12),
            if (p.description != null) Text(p.description!),
            const SizedBox(height: 12),
            Text("Total Days: ${p.totalDays}"),
          ],
        ),
      );
    }

    if (archiveId != null) {
      final archive = ref.watch(archiveDetailProvider(archiveId!));
      return _buildDetailScreen<Archive>(
        context,
        archive,
        titleBuilder: (a) => a.title,
        bodyBuilder: (a) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [if (a.description != null) Text(a.description!)],
        ),
      );
    }

    return const Scaffold(
      body: Center(child: Text("Invalid Bible Study type")),
    );
  }

  /// Helper for consistent detail screens
  Widget _buildDetailScreen<T>(
    BuildContext context,
    AsyncValue<T> asyncValue, {
    required String Function(T) titleBuilder,
    required Widget Function(T) bodyBuilder,
  }) {
    return Scaffold(
      appBar: AppBar(),
      body: asyncValue.when(
        data: (data) => Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titleBuilder(data),
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 16),
                bodyBuilder(data),
              ],
            ),
          ),
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text("Error: $err")),
      ),
    );
  }
}
