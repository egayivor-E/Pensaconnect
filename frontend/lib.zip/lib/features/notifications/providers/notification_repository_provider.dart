import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:app/core/services/api_service_provider.dart';
import 'package:app/features/notifications/data/notification_repository.dart';

final notification_repository_provider = Provider<NotificationRepository>((ref) {
  final api = ref.watch(apiServiceProvider);
  return NotificationRepository(api);
});
