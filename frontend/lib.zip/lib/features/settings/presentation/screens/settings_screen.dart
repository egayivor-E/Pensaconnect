import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/theme_provider.dart';
import '../repositories/auth_repository.dart';
import '../repositories/notification_repository.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final AuthRepository _authRepository = AuthRepository();
  late NotificationRepository _notificationRepository;
  bool _notificationsEnabled = true;
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _notificationRepository = NotificationRepository(); // ✅ no baseUrl needed
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
      });
    } catch (e) {
      debugPrint('Error loading settings: $e');
    }
  }

  Future<void> _saveNotificationPreference(bool enabled) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('notifications_enabled', enabled);

      // Also update on backend if user is authenticated
      final token = prefs.getString('auth_token');
      if (token != null) {
        await _notificationRepository.updateNotificationPreference(
          token,
          enabled,
        );
      }

      setState(() {
        _notificationsEnabled = enabled;
      });
    } catch (e) {
      debugPrint('Error saving notification preference: $e');
      setState(() {
        _errorMessage = 'Failed to update notification settings';
      });
    }
  }

  Future<void> _logout() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();

      // Call backend logout endpoint (no args needed anymore)
      await _authRepository.logout();

      // Clear local storage
      await prefs.remove('auth_token');
      await prefs.remove('user_data');

      // Navigate to login screen
      if (mounted) {
        context.go('/login');
      }
    } catch (e) {
      debugPrint('Error during logout: $e');
      setState(() {
        _errorMessage = 'Logout failed. Please try again.';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final _ = Theme.of(context);
    final themeProvider = context.watch<ThemeProvider>();
    final isDarkMode = themeProvider.themeMode == ThemeMode.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        centerTitle: true,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.shade100,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline, color: Colors.red),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: TextStyle(color: Colors.red.shade800),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, size: 16),
                            onPressed: () {
                              setState(() {
                                _errorMessage = null;
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  ),

                // Preferences Section
                _buildSectionTitle(context, 'Preferences'),
                const SizedBox(height: 8),
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      SwitchListTile(
                        title: const Text('Dark Mode'),
                        value: isDarkMode,
                        onChanged: themeProvider.toggleTheme,
                        secondary: const Icon(Icons.dark_mode_outlined),
                      ),
                      const Divider(height: 1),
                      SwitchListTile(
                        title: const Text('Enable Notifications'),
                        value: _notificationsEnabled,
                        onChanged: _saveNotificationPreference,
                        secondary: const Icon(
                          Icons.notifications_active_outlined,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Account Section
                _buildSectionTitle(context, 'Account'),
                const SizedBox(height: 8),
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      _buildTile(
                        context,
                        icon: Icons.person_outline,
                        title: 'Profile',
                        route: '/profile',
                      ),
                      const Divider(height: 1),
                      _buildTile(
                        context,
                        icon: Icons.lock_outline,
                        title: 'Change Password',
                        route: '/change-password',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Support Section
                _buildSectionTitle(context, 'Support'),
                const SizedBox(height: 8),
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      _buildTile(
                        context,
                        icon: Icons.help_outline,
                        title: 'Help & Support',
                        route: '/help',
                      ),
                      const Divider(height: 1),
                      _buildTile(
                        context,
                        icon: Icons.description_outlined,
                        title: 'Terms & Privacy',
                        route: '/terms',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 32),

                // Logout Button
                Center(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _logout,
                    icon: const Icon(Icons.logout),
                    label: const Text('Logout'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 28,
                        vertical: 14,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    final theme = Theme.of(context);
    return Text(
      title.toUpperCase(),
      style: theme.textTheme.labelLarge?.copyWith(
        fontWeight: FontWeight.bold,
        color: theme.colorScheme.primary,
        letterSpacing: 0.8,
      ),
    );
  }

  Widget _buildTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String route,
  }) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () => context.push(route),
    );
  }
}
