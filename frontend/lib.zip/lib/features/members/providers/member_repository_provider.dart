import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:app/core/services/api_service_provider.dart';
import 'package:app/features/members/data/member_repository.dart';

final member_repository_provider = Provider<MemberRepository>((ref) {
  final api = ref.watch(apiServiceProvider);
  return MemberRepository(api);
});
