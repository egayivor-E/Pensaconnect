import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/event.dart';
import '../services/api_service.dart';

class EventRepository {
  /// Fetch all events
  Future<List<EventModel>> fetchAllEvents() async {
    try {
      final response = await ApiService.get('events', headers: {});

      if (response.statusCode == 200) {
        final Map<String, dynamic> body = json.decode(response.body);

        // ✅ safely extract list
        final List<dynamic> data = body["data"] ?? [];

        return data.map((e) => EventModel.fromJson(e)).toList();
      } else {
        debugPrint(
          "❌ Failed to fetch events: ${response.statusCode} - ${response.body}",
        );
        return [];
      }
    } catch (e) {
      debugPrint("❌ Error fetching events: $e");
      return [];
    }
  }

  /// Add a new event
  Future<bool> addEvent(EventModel event) async {
    try {
      final response = await ApiService.post('events', event.toJson());
      return response.statusCode == 201;
    } catch (e) {
      debugPrint("❌ Error adding event: $e");
      return false;
    }
  }

  /// Update an existing event
  Future<bool> updateEvent(EventModel event) async {
    try {
      final response = await ApiService.put(
        'events/${event.id}',
        event.toJson(),
      );
      return response.statusCode == 200;
    } catch (e) {
      debugPrint("❌ Error updating event: $e");
      return false;
    }
  }

  /// Delete event
  Future<bool> deleteEvent(String id) async {
    try {
      final response = await ApiService.delete('events/$id');
      return response.statusCode == 200;
    } catch (e) {
      debugPrint("❌ Error deleting event: $e");
      return false;
    }
  }

  /// Fetch attendees for an event
  Future<List<Map<String, dynamic>>> fetchAttendees(String eventId) async {
    try {
      final response = await ApiService.get(
        'events/$eventId/attendees',
        headers: {},
      );
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(json.decode(response.body));
      }
      return [];
    } catch (e) {
      debugPrint("❌ Error fetching attendees: $e");
      return [];
    }
  }

  /// Fetch reminders for an event
  Future<List<Map<String, dynamic>>> fetchReminders(String eventId) async {
    try {
      final response = await ApiService.get(
        'events/$eventId/reminders',
        headers: {},
      );
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(json.decode(response.body));
      }
      return [];
    } catch (e) {
      debugPrint("❌ Error fetching reminders: $e");
      return [];
    }
  }
}
