import 'dart:ui';

class EventModel {
  final String id;
  final String title;
  final String description;
  final String eventType;
  final DateTime? startTime; // nullable
  final DateTime? endTime; // nullable
  final String? location;
  final bool isVirtual;
  final String category;
  final bool isFeatured;
  final String? imageUrl;
  final int colorValue;

  EventModel({
    required this.id,
    required this.title,
    required this.description,
    required this.eventType,
    required this.startTime,
    required this.endTime,
    this.location,
    this.isVirtual = false,
    this.category = 'General',
    this.isFeatured = false,
    this.imageUrl,
    this.colorValue = 0xFF2196F3, // default blue color
  });

  /// Use startTime as the main date
  DateTime? get date => startTime;

  /// Convert integer color value to Color
  Color get color => Color(colorValue);

  factory EventModel.fromJson(Map<String, dynamic> json) {
    return EventModel(
      id: json['id'].toString(),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      eventType: json['event_type'] ?? 'general',
      startTime: json['start_time'] != null
          ? DateTime.parse(json['start_time'])
          : null,
      endTime: json['end_time'] != null
          ? DateTime.parse(json['end_time'])
          : null,
      location: json['location'],
      isVirtual: json['is_virtual'] ?? false,
      category: json['category'] ?? 'General',
      isFeatured: json['isFeatured'] ?? false,
      imageUrl: json['imageUrl'],
      colorValue: json['colorValue'] ?? 0xFF2196F3,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'event_type': eventType,
      'start_time': startTime?.toIso8601String(),
      'end_time': endTime?.toIso8601String(),
      'location': location,
      'is_virtual': isVirtual,
      'category': category,
      'isFeatured': isFeatured,
      'imageUrl': imageUrl,
      'colorValue': colorValue,
    };
  }
}
