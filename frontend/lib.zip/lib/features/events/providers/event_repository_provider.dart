import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:app/core/services/api_service_provider.dart';
import 'package:app/features/events/data/event_repository.dart';

final event_repository_provider = Provider<EventRepository>((ref) {
  final api = ref.watch(apiServiceProvider);
  return EventRepository(api);
});
