import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:app/core/services/api_service_provider.dart';
import 'package:app/features/activity/data/activity_repository.dart';

final activity_repository_provider = Provider<ActivityRepository>((ref) {
  final api = ref.watch(apiServiceProvider);
  return ActivityRepository(api);
});
