import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/user.dart';
import '../services/api_service.dart';

class UserRepository {
  /// Fetch the currently authenticated user using the stored token
  Future<User?> getCurrentUser(String token) async {
    try {
      final response = await ApiService.get(
        'auth/me', // ✅ make sure this matches your backend route
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // if backend wraps response in "data"
        if (data is Map<String, dynamic> && data.containsKey('data')) {
          return User.fromJson(data['data']);
        }

        // else assume direct user JSON
        return User.fromJson(data);
      } else {
        debugPrint(
          "❌ Failed to fetch current user: ${response.statusCode} - ${response.body}",
        );
        return null;
      }
    } catch (e) {
      debugPrint("❌ Error fetching current user: $e");
      return null;
    }
  }

  /// Fetch user profile by ID
  Future<User?> fetchUserProfile(String userId) async {
    try {
      final response = await ApiService.get('users/$userId');

      if (response.statusCode == 200) {
        return User.fromJson(json.decode(response.body));
      } else {
        debugPrint(
          "❌ Failed to load user profile: ${response.statusCode} - ${response.body}",
        );
        return null;
      }
    } catch (e) {
      debugPrint("❌ Error fetching user profile: $e");
      return null;
    }
  }

  /// Update user profile
  Future<User?> updateUserProfile(
    String userId,
    Map<String, dynamic> updates,
  ) async {
    try {
      final response = await ApiService.put('users/$userId', updates);

      if (response.statusCode == 200) {
        return User.fromJson(json.decode(response.body));
      } else {
        debugPrint("❌ Failed to update user: ${response.body}");
        return null;
      }
    } catch (e) {
      debugPrint("❌ Error updating user: $e");
      return null;
    }
  }
}
