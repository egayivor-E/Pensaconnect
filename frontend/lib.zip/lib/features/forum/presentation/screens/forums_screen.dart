import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ForumsScreen extends StatelessWidget {
  final String title;

  const ForumsScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final forums = [
      "General Discussion",
      "Bible Study",
      "Prayer Requests",
      "Testimonies",
      "Youth Ministry",
    ];

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView.builder(
        itemCount: forums.length,
        itemBuilder: (context, index) {
          final forum = forums[index];
          return ListTile(
            title: Text(forum),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              // ✅ Use path parameter instead of extra
              context.go('/forums/detail/${Uri.encodeComponent(forum)}');
            },
          );
        },
      ),
    );
  }
}
