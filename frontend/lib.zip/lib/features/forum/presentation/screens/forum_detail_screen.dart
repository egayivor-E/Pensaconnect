// forum_detail_screen.dart
import 'package:flutter/material.dart';

class ForumDetailScreen extends StatelessWidget {
  final String title;

  const ForumDetailScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final posts = [
      "Welcome to $title",
      "First post in $title",
      "Share your thoughts here",
      "Any questions about $title?",
    ];

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView.builder(
        itemCount: posts.length,
        itemBuilder: (context, index) {
          final post = posts[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListTile(
              title: Text(post),
              subtitle: const Text("Click to view post details"),
              onTap: () {
                // later you can add post detail navigation here
                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(SnackBar(content: Text("Tapped on: $post")));
              },
            ),
          );
        },
      ),
    );
  }
}
