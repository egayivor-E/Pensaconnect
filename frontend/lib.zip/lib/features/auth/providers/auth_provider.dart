import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/services/api_service.dart';
import '../../../core/services/api_service_provider.dart';

class AuthState {
  final String? token;
  final String? userId;
  final bool isLoading;
  final String? error;
  const AuthState({this.token, this.userId, this.isLoading = false, this.error});
  bool get isAuthenticated => token != null;
  AuthState copyWith({String? token, String? userId, bool? isLoading, String? error}) =>
      AuthState(token: token ?? this.token, userId: userId ?? this.userId, isLoading: isLoading ?? this.isLoading, error: error);
  factory AuthState.initial() => const AuthState();
}

class AuthNotifier extends StateNotifier<AuthState> {
  StreamSubscription<String?>? _tokenSub;
  final ApiService api;
  AuthNotifier(this.api): super(AuthState.initial()) { _init(); }
  Future<void> _init() async {
    state = state.copyWith(isLoading: true);
    try {
      final token = await api.getToken();
      final userId = await api.getUserId();
      state = state.copyWith(token: token, userId: userId, isLoading: false);
      _tokenSub = api.tokenStream.listen((t) => state = state.copyWith(token: t));
    } catch (e) { state = state.copyWith(error: e.toString(), isLoading: false); }
  }
  Future<void> login(String email, String password) async {
    state = state.copyWith(isLoading: true, error: null);
    try { final resp = await api.login(email, password);
      state = state.copyWith(token: resp['token'], userId: resp['userId'], isLoading: false);
    } catch (e) { state = state.copyWith(error: e.toString(), isLoading: false); }
  }
  Future<void> logout() async { await api.logout(); state = AuthState.initial(); }
  @override void dispose(){ _tokenSub?.cancel(); super.dispose(); }
}
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref){
  final api = ref.watch(apiServiceProvider);
  return AuthNotifier(api);
});
