import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/api_service.dart';
import '../models/user.dart';

/// Immutable Auth State
class AuthState {
  final String? token;
  final String? userId;
  final bool isLoading;
  final String? error;

  const AuthState({
    this.token,
    this.userId,
    this.isLoading = false,
    this.error,
  });

  bool get isAuthenticated => token != null;

  AuthState copyWith({
    String? token,
    String? userId,
    bool? isLoading,
    String? error,
  }) {
    return AuthState(
      token: token ?? this.token,
      userId: userId ?? this.userId,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }

  factory AuthState.initial() => const AuthState();
}

/// Auth Notifier
class AuthNotifier extends StateNotifier<AuthState> {
  StreamSubscription<String?>? _tokenSubscription;

  AuthNotifier() : super(AuthState.initial()) {
    _init();
  }

  Future<void> _init() async {
    state = state.copyWith(isLoading: true);
    try {
      final token = await ApiService.getToken();
      final userId = await ApiService.getUserId();

      state = state.copyWith(token: token, userId: userId, isLoading: false);

      // Subscribe to token changes
      _tokenSubscription = ApiService.tokenStream.listen((token) {
        state = state.copyWith(token: token);
      });
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> login(String email, String password) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await ApiService.login(email, password);
      final token = response['token'];
      final userId = response['userId'];

      state = state.copyWith(token: token, userId: userId, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> logout() async {
    await ApiService.logout();
    state = AuthState.initial();
  }

  @override
  void dispose() {
    _tokenSubscription?.cancel();
    super.dispose();
  }
}

/// Riverpod Provider
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>(
  (ref) => AuthNotifier(),
);
