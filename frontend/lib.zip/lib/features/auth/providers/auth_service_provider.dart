import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:app/core/services/api_service_provider.dart';
import 'package:app/features/auth/data/auth_service.dart';

final auth_service_provider = Provider<AuthService>((ref) {
  final api = ref.watch(apiServiceProvider);
  return AuthService(api);
});
