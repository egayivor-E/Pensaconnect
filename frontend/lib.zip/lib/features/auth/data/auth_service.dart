import 'dart:convert';
import 'dart:developer' as developer;
import 'api_service.dart';

class AuthService {
  /// Register a new user
  Future<Map<String, dynamic>> register(
    String username,
    String email,
    String password,
  ) async {
    final payload = {
      "username": username,
      "email": email,
      "password": password,
    };

    developer.log(
      "Register Payload: ${json.encode(payload)}",
      name: "AuthService",
    );

    final response = await ApiService.post("auth/register", payload);

    developer.log("Register Response: ${response.body}", name: "AuthService");

    return json.decode(response.body) as Map<String, dynamic>;
  }

  /// Login with either username OR email
  Future<Map<String, dynamic>> login(String identifier, String password) async {
    final payload = {"identifier": identifier, "password": password};

    developer.log(
      "Login Payload: ${json.encode(payload)}",
      name: "AuthService",
    );

    final response = await ApiService.post("auth/login", payload);

    developer.log("Login Response: ${response.body}", name: "AuthService");

    return json.decode(response.body) as Map<String, dynamic>;
  }
}
