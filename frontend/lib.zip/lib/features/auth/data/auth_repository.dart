import 'dart:convert';
import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/user.dart';

class AuthRepository {
  /// 🔹 Login with identifier & password
  Future<Map<String, dynamic>?> login(
    String identifier,
    String password,
  ) async {
    try {
      final response = await ApiService.post('auth/login', {
        'identifier': identifier,
        'password': password,
      });

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Save tokens globally
        await ApiService.setTokens(
          data['data']['access_token'],
          data['data']['refresh_token'],
        );

        return data['data']; // contains user + tokens
      } else {
        debugPrint("❌ Login failed: ${response.statusCode} - ${response.body}");
        return null;
      }
    } catch (e) {
      debugPrint("❌ Login error: $e");
      return null;
    }
  }

  /// 🔹 Logout user
  Future<void> logout() async {
    try {
      await ApiService.post('auth/logout', {});
    } catch (e) {
      debugPrint("⚠️ Error logging out (ignored): $e");
    } finally {
      await ApiService.clearTokens();
    }
  }

  /// 🔹 Return currently stored **access token**
  Future<String?> getToken() async {
    return ApiService.authToken;
  }

  /// 🔹 Return currently stored **refresh token**
  Future<Future<void> Function()> getRefreshToken() async {
    return ApiService.refreshToken;
  }

  /// 🔹 Get current logged-in user (from `/auth/me` or similar)
  Future<User?> getCurrentUser() async {
    try {
      final response = await ApiService.get('auth/me', headers: {});

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return User.fromJson(data['data']);
      } else {
        debugPrint(
          "❌ Failed to fetch current user: ${response.statusCode} - ${response.body}",
        );
        return null;
      }
    } catch (e) {
      debugPrint("❌ Error fetching current user: $e");
      return null;
    }
  }

  /// 🔹 Helper: Get current user ID (for chats, ownership, etc.)
  Future<String?> getCurrentUserId() async {
    final user = await getCurrentUser();
    return user?.id.toString();
  }
}
