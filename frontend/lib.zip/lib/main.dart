import 'package:flutter_riverpod/flutter_riverpod.dart';
// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

// Screens
import 'screens/bible_study_detail_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/home_screen.dart';
import 'screens/live_stream_screen.dart';
import 'screens/test_connection_screen.dart';
import 'screens/events_screen.dart';
import 'screens/bible_study_screen.dart';
import 'screens/worship_screen.dart';
import 'screens/worship_player_screen.dart';
import 'screens/forums_screen.dart';
import 'screens/forum_detail_screen.dart';
import 'screens/prayer_wall_screen.dart';
import 'screens/testimonies_screen.dart';
import 'screens/group_chats_screen.dart';
import 'screens/group_chat_detail_screen.dart';
import 'screens/anonymous_chat_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_screen.dart';

// Providers
import 'providers/auth_provider.dart';
import 'providers/theme_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");

  final authProvider = AuthProvider();
  final autoLoggedIn = await authProvider.tryAutoLogin();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: authProvider),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ],
      child: MyApp(autoLoggedIn: autoLoggedIn),
    ),
  );
}

class MyApp extends StatelessWidget {
  final bool autoLoggedIn;
  const MyApp({super.key, required this.autoLoggedIn});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'PensaConnect',
      theme: themeProvider.getThemeData(Brightness.light),
      darkTheme: themeProvider.getThemeData(Brightness.dark),
      themeMode: themeProvider.themeMode,
      routerConfig: _router(context),
    );
  }

  GoRouter _router(BuildContext context) {
    return GoRouter(
      initialLocation: '/splash',
      routes: [
        /// 🔹 Auth
        GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),
        GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
        GoRoute(path: '/register', builder: (_, __) => const RegisterScreen()),

        /// 🔹 Home
        GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),

        /// 🔹 Live / Test
        GoRoute(path: '/live', builder: (_, __) => const LiveStreamScreen()),
        GoRoute(
          path: '/test',
          builder: (_, __) => const TestConnectionScreen(),
        ),

        /// 🔹 Events
        GoRoute(path: '/events', builder: (_, __) => const EventsScreen()),

        /// 🔹 Bible Study
        GoRoute(path: '/bible', builder: (_, __) => const BibleStudyScreen()),
        GoRoute(
          path: '/bible/detail/:id',
          builder: (context, state) {
            final item = state.extra; // Devotion OR StudyPlan OR ArchiveItem
            return BibleStudyDetailScreen(item: item);
          },
        ),

        /// 🔹 Worship
        GoRoute(path: '/worship', builder: (_, __) => const WorshipScreen()),
        GoRoute(
          path: '/worship/player',
          builder: (context, state) {
            final extra = state.extra as Map<String, dynamic>? ?? {};
            final songs = (extra['songs'] as List<Map<String, dynamic>>?) ?? [];
            final initialIndex = extra['initialIndex'] as int? ?? 0;
            return WorshipPlayerScreen(
              songs: songs,
              initialIndex: initialIndex,
            );
          },
        ),

        /// 🔹 Forums
        GoRoute(
          path: '/forums',
          builder: (_, __) => const ForumsScreen(title: 'Discussion Forums'),
        ),
        GoRoute(
          path: '/forums/detail/:title',
          builder: (context, state) {
            final title = state.pathParameters['title'] ?? 'Discussion';
            return ForumDetailScreen(title: title);
          },
        ),

        /// 🔹 Prayer & Testimonies
        GoRoute(path: '/prayer', builder: (_, __) => const PrayerWallScreen()),
        GoRoute(
          path: '/testimonies',
          builder: (_, __) => const TestimoniesScreen(),
        ),

        /// 🔹 Group Chats
        GoRoute(
          path: '/group-chats',
          builder: (_, __) => const GroupChatsScreen(),
        ),
        GoRoute(
          path: '/group-chat/detail',
          builder: (context, state) {
            final extras = state.extra as Map<String, dynamic>? ?? {};
            return GroupChatDetailScreen(
              groupId: extras['groupId'] as String? ?? '',
              groupName: extras['groupName'] as String? ?? 'Group Chat',
            );
          },
        ),

        /// 🔹 Anonymous Chat
        GoRoute(
          path: '/anonymous-chat',
          builder: (context, state) {
            final extras = state.extra as Map<String, dynamic>? ?? {};
            return AnonymousChatScreen(
              chatId: extras['chatId'] as String? ?? 'anonymous',
              topic: extras['topic'] as String? ?? 'Anonymous Chat',
            );
          },
        ),

        /// 🔹 Profile & Settings
        GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
        GoRoute(path: '/settings', builder: (_, __) => const SettingsScreen()),
      ],

      /// 🔹 Redirect rules
      redirect: (context, state) {
        final authProvider = context.read<AuthProvider>();
        final isAuthenticated = authProvider.isAuthenticated;
        final location = state.uri.toString();

        final isSplash = location == '/splash';
        final isLogin = location == '/login';
        final isRegister = location == '/register';

        if (!isAuthenticated && !isLogin && !isSplash && !isRegister) {
          return '/login';
        }
        if (isAuthenticated && (isLogin || isSplash || isRegister)) {
          return '/home';
        }
        return null;
      },

      /// 🔹 Error screen
      errorBuilder: (context, state) => Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('404 - Page Not Found'),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => context.go('/home'),
                child: const Text('Return Home'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
