import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'dart:developer' as developer;

/// 🔹 API Service Class - Handles all HTTP requests
class ApiService {
  static const Duration timeoutDuration = Duration(seconds: 30);
  static String? _authToken;
  static String? _refreshToken;
  static Timer? _refreshTimer;

  static List<RequestInterceptor> requestInterceptors = [];
  static List<ResponseInterceptor> responseInterceptors = [];

  // === TOKEN HANDLING ===

  /// Token change stream
  static final StreamController<String?> _tokenStreamController =
      StreamController<String?>.broadcast();

  /// Public stream getter (AuthProvider can listen)
  static Stream<String?> get tokenStream => _tokenStreamController.stream;

  /// Public getter (read-only)
  static String? get authToken => _authToken;

  /// Initialize ApiService (loads token + refresh token from storage)
  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _authToken = prefs.getString("access_token");
    _refreshToken = prefs.getString("refresh_token");

    if (_authToken != null) {
      developer.log("✅ Loaded saved access token", name: "ApiService");
    }
    if (_refreshToken != null) {
      developer.log("✅ Loaded saved refresh token", name: "ApiService");
    }

    _tokenStreamController.add(_authToken);

    if (_authToken != null && _refreshToken != null) {
      _scheduleTokenRefresh(); // auto-start
    }
  }

  /// Save tokens globally + persist in storage
  static Future<void> setTokens(
    String? accessToken,
    String? refreshToken,
  ) async {
    _authToken = accessToken;
    _refreshToken = refreshToken;
    final prefs = await SharedPreferences.getInstance();

    if (accessToken != null) {
      await prefs.setString("access_token", accessToken);
      developer.log("🔑 Access token saved", name: "ApiService");
    } else {
      await prefs.remove("access_token");
    }

    if (refreshToken != null) {
      await prefs.setString("refresh_token", refreshToken);
      developer.log("🔄 Refresh token saved", name: "ApiService");
    } else {
      await prefs.remove("refresh_token");
    }

    _tokenStreamController.add(_authToken);
    _scheduleTokenRefresh();
  }

  /// Clear tokens (logout)
  static Future<void> clearTokens() async {
    _authToken = null;
    _refreshToken = null;
    _refreshTimer?.cancel();

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove("access_token");
    await prefs.remove("refresh_token");

    developer.log("🚪 Tokens cleared (logout)", name: "ApiService");
    _tokenStreamController.add(null);
  }

  // === AUTO REFRESH ===

  /// Schedules token refresh ~1 min before expiry
  static void _scheduleTokenRefresh() {
    _refreshTimer?.cancel();

    // ⚠️ Hardcoded to 14 minutes (Flask token = 15min default unless set differently)
    const refreshBefore = Duration(minutes: 14);

    _refreshTimer = Timer(refreshBefore, () async {
      await refreshToken();
    });
  }

  /// Calls backend refresh endpoint
  static Future<void> refreshToken() async {
    if (_refreshToken == null) {
      developer.log("⚠️ No refresh token, cannot refresh", name: "ApiService");
      return;
    }

    try {
      final uri = _buildUri("auth/refresh");

      final response = await http
          .post(
            uri,
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'Authorization': 'Bearer $_refreshToken', // ✅ ONLY header
            },
          )
          .timeout(timeoutDuration);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        final newAccess = data["data"]?["access_token"];
        // Flask doesn't return a new refresh token → reuse old one
        final newRefresh = data["data"]?["refresh_token"] ?? _refreshToken;

        if (newAccess != null) {
          await setTokens(newAccess, newRefresh);
          developer.log("✅ Token refreshed successfully", name: "ApiService");
        }
      } else {
        developer.log(
          "❌ Refresh failed (${response.statusCode}) → forcing logout",
          name: "ApiService",
        );
        await clearTokens();
      }
    } catch (e) {
      developer.log("❌ Refresh error: $e", name: "ApiService");
      await clearTokens();
    }
  }

  /// Ensures token is still valid before requests
  static Future<void> _ensureValidToken() async {
    if (_authToken != null && _isTokenExpired(_authToken!)) {
      developer.log(
        "🔄 Access token expired → refreshing...",
        name: "ApiService",
      );
      await refreshToken();
    }
  }

  /// Decode JWT expiry and check
  static bool _isTokenExpired(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) return true;

      final payload = utf8.decode(
        base64Url.decode(base64Url.normalize(parts[1])),
      );
      final payloadMap = json.decode(payload);

      final exp = payloadMap['exp'];
      if (exp == null) return true;

      final expiryDate = DateTime.fromMillisecondsSinceEpoch(exp * 1000);
      return DateTime.now().isAfter(expiryDate.subtract(Duration(seconds: 30)));
    } catch (_) {
      return true;
    }
  }

  // === CONFIGURATION ===

  static String get _baseUrl {
    try {
      return dotenv.get('BACKEND_URL');
    } catch (_) {
      const fallbackUrl = 'http://localhost:5000';
      developer.log(
        'Error loading .env, using fallback URL: $fallbackUrl',
        name: 'ApiService',
      );
      return fallbackUrl;
    }
  }

  static String get _apiPrefix {
    try {
      final prefix = dotenv.get('API_PREFIX');
      return prefix.isNotEmpty ? prefix : 'api/v1';
    } catch (_) {
      return 'api/v1';
    }
  }

  // === REQUEST HELPERS ===

  static Future<http.Response> get(
    String endpoint, {
    Map<String, dynamic>? queryParams,
    Map<String, String>? headers,
  }) async {
    await _ensureValidToken();
    final uri = _buildUri(endpoint, queryParams: queryParams);
    developer.log('GET: $uri', name: 'ApiService');

    final request = http.Request('GET', uri);

    // Merge default headers + custom headers
    request.headers.addAll(_headers);
    if (headers != null) {
      request.headers.addAll(headers);
    }

    _runRequestInterceptors(request);

    final response = await http.Response.fromStream(
      await request.send().timeout(timeoutDuration),
    );
    _runResponseInterceptors(response);

    return _handleResponse(response);
  }

  static Future<http.Response> post(String endpoint, dynamic data) async {
    await _ensureValidToken();
    final uri = _buildUri(endpoint);
    final body = json.encode(data);

    developer.log('POST: $uri', name: 'ApiService');
    developer.log('Request Body: $body', name: 'ApiService');

    final request = http.Request('POST', uri);
    request.headers.addAll(_headers);
    request.body = body;
    _runRequestInterceptors(request);

    final response = await http.Response.fromStream(
      await request.send().timeout(timeoutDuration),
    );
    _runResponseInterceptors(response);

    return _handleResponse(response);
  }

  static Future<http.Response> put(String endpoint, dynamic data) async {
    await _ensureValidToken();
    final uri = _buildUri(endpoint);
    final request = http.Request('PUT', uri);
    request.headers.addAll(_headers);
    request.body = json.encode(data);
    _runRequestInterceptors(request);

    final response = await http.Response.fromStream(
      await request.send().timeout(timeoutDuration),
    );
    _runResponseInterceptors(response);

    return _handleResponse(response);
  }

  static Future<http.Response> patch(String endpoint, dynamic data) async {
    await _ensureValidToken();
    final uri = _buildUri(endpoint);
    final request = http.Request('PATCH', uri);
    request.headers.addAll(_headers);
    request.body = json.encode(data);
    _runRequestInterceptors(request);

    final response = await http.Response.fromStream(
      await request.send().timeout(timeoutDuration),
    );
    _runResponseInterceptors(response);

    return _handleResponse(response);
  }

  static Future<http.Response> delete(String endpoint) async {
    await _ensureValidToken();
    final uri = _buildUri(endpoint);
    final request = http.Request('DELETE', uri);
    request.headers.addAll(_headers);
    _runRequestInterceptors(request);

    final response = await http.Response.fromStream(
      await request.send().timeout(timeoutDuration),
    );
    _runResponseInterceptors(response);

    return _handleResponse(response);
  }

  // === INTERNAL HELPERS ===

  static Uri _buildUri(String endpoint, {Map<String, dynamic>? queryParams}) {
    final cleanEndpoint = endpoint.replaceAll(RegExp(r'^/|/$'), '');
    final url = _sanitizeUrl('$_baseUrl/$_apiPrefix/$cleanEndpoint');
    var uri = Uri.parse(url);

    if (queryParams != null) {
      final queryParameters = {
        ...uri.queryParameters,
        ...queryParams.map((k, v) => MapEntry(k, v.toString())),
      };
      uri = uri.replace(queryParameters: queryParameters);
    }
    return uri;
  }

  static String _sanitizeUrl(String url) {
    return url.replaceAll(RegExp(r'(?<!:)/+'), '/');
  }

  static Map<String, String> get _headers {
    final headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (_authToken != null) {
      headers['Authorization'] = 'Bearer $_authToken';
    }
    return headers;
  }

  static void _runRequestInterceptors(http.BaseRequest request) {
    for (final interceptor in requestInterceptors) {
      interceptor(request);
    }
  }

  static void _runResponseInterceptors(http.Response response) {
    for (final interceptor in responseInterceptors) {
      interceptor(response);
    }
  }

  static http.Response _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return response;
    } else {
      final errorData = _tryParseError(response.body);
      throw ApiException(
        statusCode: response.statusCode,
        message:
            errorData['message'] ??
            'Request failed with status ${response.statusCode}',
        details: errorData,
      );
    }
  }

  // ignore: unused_element
  static Exception _sanitizeError(dynamic error) {
    if (error is ApiException) return error;
    if (error is TimeoutException) {
      return ApiException(
        statusCode: 408,
        message: 'Request timeout',
        details: {'type': 'timeout'},
      );
    }
    if (error is http.ClientException) {
      return ApiException(
        statusCode: 0,
        message: 'Network error: ${error.message}',
        details: {'type': 'network', 'original_error': error.toString()},
      );
    }
    return ApiException(
      statusCode: 0,
      message: 'Unexpected error: ${error.toString()}',
      details: {'type': 'unknown', 'original_error': error.toString()},
    );
  }

  static Map<String, dynamic> _tryParseError(String body) {
    try {
      return json.decode(body) as Map<String, dynamic>;
    } catch (_) {
      return {
        'raw_response': body.length > 200
            ? '${body.substring(0, 200)}...'
            : body,
      };
    }
  }
}

/// 🔹 Request Interceptor Typedef
typedef RequestInterceptor = void Function(http.BaseRequest request);

/// 🔹 Response Interceptor Typedef
typedef ResponseInterceptor = void Function(http.Response response);

/// 🔹 API Exception Class
class ApiException implements Exception {
  final int statusCode;
  final String message;
  final dynamic details;

  ApiException({required this.statusCode, required this.message, this.details});

  @override
  String toString() =>
      'ApiException: [$statusCode] $message${details != null ? ' - $details' : ''}';
}
