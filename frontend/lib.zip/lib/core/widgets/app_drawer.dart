import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppDrawer extends StatelessWidget {
  final void Function(int)? onItemTap;

  const AppDrawer({super.key, this.onItemTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bool isLargeScreen = MediaQuery.of(context).size.width >= 800;

    return Drawer(
      width: isLargeScreen ? 280 : null,
      child: Column(
        children: [
          UserAccountsDrawerHeader(
            accountName: const Text("Welcome to PensaConnect"),
            accountEmail: const Text("Ladies & Gents Wing"),
            currentAccountPicture: CircleAvatar(
              backgroundColor: theme.colorScheme.primary,
              child: const Icon(Icons.people_alt, color: Colors.white),
            ),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary,
              image: DecorationImage(
                image: const AssetImage('assets/images/drawer_bg.png'),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                  theme.colorScheme.primary.withOpacity(0.8),
                  BlendMode.darken,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _buildDrawerItem(
                  context,
                  icon: Icons.home,
                  title: 'Home',
                  index: 0,
                  route: '/home',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.calendar_today,
                  title: 'Events',
                  route: '/events',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.book,
                  title: 'Bible Study',
                  route: '/bible',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.music_note,
                  title: 'Praise & Worship',
                  route: '/worship',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.live_tv,
                  title: 'Live Stream',
                  route: '/live',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.forum,
                  title: 'Discussion Forums',
                  route: '/forums',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.self_improvement,
                  title: 'Prayer Wall',
                  route: '/prayer',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.auto_stories,
                  title: 'Testimonies',
                  route: '/testimonies',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.chat,
                  title: 'Group Chats',
                  route: '/chats',
                ),
                const Divider(),
                _buildDrawerItem(
                  context,
                  icon: Icons.person,
                  title: 'My Profile',
                  route: '/profile',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.settings,
                  title: 'Settings',
                  route: '/settings',
                ),
                _buildDrawerItem(
                  context,
                  icon: Icons.help,
                  title: 'Help & Support',
                  route: '/help',
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'PensaConnect v1.0',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    String? route,
    int? index,
  }) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      onTap: () {
        if (index != null && onItemTap != null) onItemTap!(index);
        if (Scaffold.maybeOf(context)?.isDrawerOpen ?? false)
          Navigator.of(context).pop();
        if (route != null) context.push(route);
      },
    );
  }
}
