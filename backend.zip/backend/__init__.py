# backend/__init__.py
from __future__ import annotations
import os
import logging
from pathlib import Path
from typing import Optional
import secrets
from flask import g, request


from backend.admin import register_admin
from flask import Blueprint, Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_smorest import Api   # type: ignore # ✅ Swagger API

from backend.config import ProductionConfig, DevelopmentConfig, TestingConfig, StagingConfig
from backend.extensions import (
    configure_extensions, db, limiter, jwt, 
    cache, init_celery, celery
)
from backend.middleware import register_error_handlers
# This is the correct import for your auth blueprint
from backend.api import api_v1

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)



def _set_csp_headers(app: Flask):
    @app.before_request
    def set_nonce():
        # Generate a random nonce per request
        g.csp_nonce = secrets.token_urlsafe(16)

    @app.after_request
    def apply_csp(response):
        nonce = getattr(g, "csp_nonce", "")
        csp = (
            f"default-src 'self'; "
            f"script-src 'self' 'nonce-{nonce}' https://cdn.jsdelivr.net; "
            f"style-src 'self' 'nonce-{nonce}' https://cdn.jsdelivr.net; "
            f"img-src 'self' data:; "
            f"font-src 'self' https://cdn.jsdelivr.net; "
            f"connect-src 'self'; "
            f"object-src 'none'; "
            f"base-uri 'self'; "
            f"form-action 'self'; "
        )
        response.headers["Content-Security-Policy"] = csp
        return response





def create_app(config_name: Optional[str] = None) -> Flask:
    """Application factory for creating Flask app"""
    root_dir = Path(__file__).parent.parent
    frontend_build = root_dir / "frontend" / "build"

    static_folder = str(frontend_build) if frontend_build.exists() else None
    app = Flask(
        __name__,
        static_folder=static_folder,
        static_url_path="/" if static_folder else None,
    )
    
    


    # ✅ Config FIRST (before extensions)
    _configure_app(app, config_name)
    
    # ✅ Configure API docs BEFORE creating Api instance
    _configure_api_docs(app)
    
    # ✅ SIMPLE CORS configuration
    CORS(app,
     resources={r"/api/*": {
         "origins": [
             "http://localhost:58672",
             "http://localhost:*",
             "http://127.0.0.1:*",
             "http://0.0.0.0:*"
         ],
         "methods": ["GET", "POST", "PUT","PATCH", "DELETE", "OPTIONS"],
         "allow_headers": ["Content-Type", "Authorization"],
         "supports_credentials": True,
         "expose_headers": ["Content-Type", "Authorization"]
     }})
    
    # ✅ Extensions AFTER config
    configure_extensions(app)
    register_admin(app)
    
    # ✅ Secure CSP headers with nonce
    _set_csp_headers(app)

    


    # ✅ API setup - NOW this will work because config is already set
    api = Api(app)

    # 🔹 Register the single API v1 blueprint directly
    
    app.register_blueprint(api_v1)
    
    logger.info("✅ API v1 blueprint registered successfully")

    # Cache, Celery, Middleware
    _configure_cache(app)
    _configure_celery(app)
    _register_middleware(app)
    _register_cli(app)
    register_health(app)
    
    @app.before_request
    def log_request_info():
        logger.info(f"Incoming request: {request.method} {request.path}")
        logger.info(f"Origin: {request.headers.get('Origin')}")

    # ✅ Serve frontend (SPA fallback)
    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve(path: str):
        if not frontend_build.exists():
            logger.warning("⚠️ Frontend build not found at %s", frontend_build)
            return jsonify({"error": "Frontend not built"}), 404

        file_path = frontend_build / path
        if file_path.exists() and file_path.is_file():
            return send_from_directory(frontend_build, path)

        return send_from_directory(frontend_build, "index.html")

    logger.info(f"✅ App initialized in {app.config['ENV']} mode")
    
    @app.context_processor
    def inject_nonce():
        return {"csp_nonce": getattr(g, "csp_nonce", "")}

    
    return app



# ---------------- Config ----------------
def _configure_app(app: Flask, config_name: Optional[str]):
    if not config_name:
        config_name = os.getenv("FLASK_ENV", "development")

    config_map = {
        "production": ProductionConfig,
        "staging": StagingConfig,
        "testing": TestingConfig,
        "development": DevelopmentConfig,
    }
    app.config.from_object(config_map.get(config_name, DevelopmentConfig))
    app.config.from_pyfile("config.py", silent=True)
    app.config.from_prefixed_env()

    os.makedirs(app.instance_path, exist_ok=True)
    app.config["ENV"] = config_name


def _configure_api_docs(app: Flask):
    """Configure OpenAPI / Swagger / Redoc docs - MUST be called before Api() creation"""
    app.config.update(
        API_TITLE="PensaConnect API",
        API_VERSION="v1",
        OPENAPI_VERSION="3.0.3",
        OPENAPI_URL_PREFIX="/docs",
        OPENAPI_SWAGGER_UI_PATH="/swagger-ui",
        OPENAPI_SWAGGER_UI_URL="https://cdn.jsdelivr.net/npm/swagger-ui-dist/",
        OPENAPI_REDOC_PATH="/redoc",
        OPENAPI_REDOC_URL="https://cdn.jsdelivr.net/npm/redoc/bundles/redoc.standalone.js",
    )
    logger.info("✅ API Docs configured") 
    
    

# ---------------- Cache / Celery ----------------
def _configure_cache(app: Flask):
    """Configure cache if available"""
    if cache:
        try:
            cache.init_app(app)
            logger.info("✅ Cache initialized")
        except Exception as e:
            logger.warning(f"⚠️ Cache initialization failed: {e}")

def _configure_celery(app: Flask):
    """Configure Celery if available"""
    if celery:
        try:
            # Initialize celery with app context
            init_celery(app)
            logger.info("✅ Celery initialized")
            
            # Try to register tasks
            try:
                from backend.tasks import register_tasks
                register_tasks(celery)
                logger.info("✅ Celery tasks registered")
            except ImportError:
                logger.warning("⚠️ No tasks module found, skipping Celery tasks")
        except Exception as e:
            logger.warning(f"⚠️ Celery initialization failed: {e}")

# ---------------- Middleware ----------------
def _register_middleware(app: Flask):
    """Register middleware and error handlers"""
    register_error_handlers(app)

    @app.before_request
    def log_request():
        logger.debug(f"{request.method} {request.path}")
        

# ---------------- CLI ----------------
def _register_cli(app: Flask):
    """Register CLI commands"""
    @app.cli.command("init-db")
    def init_db():
        """Initialize database"""
        with app.app_context():
            db.create_all()
            logger.info("✅ Database initialized")

    @app.cli.command("seed-db")
    def seed_db():
        """Seed database with sample data"""
        with app.app_context():
            try:
                from backend.seeds import seed_database
                seed_database()
                logger.info("✅ Database seeded")
            except ImportError:
                logger.warning("⚠️ Seed module not found")

    @app.cli.command("create-admin")
    def create_admin():
        """Create admin user"""
        with app.app_context():
            try:
                from backend.utils import create_admin_user
                create_admin_user()
                logger.info("✅ Admin user created")
            except ImportError:
                logger.warning("⚠️ Utils module not found")

# ---------------- Health ----------------
def register_health(app: Flask):
    """Register health check endpoints"""
    @app.route("/health")
    def health_check():
        """Health check endpoint"""
        try:
            db.session.execute("SELECT 1")
            db_status = "connected"
        except Exception as e:
            db_status = f"disconnected: {str(e)}"

        return jsonify({
            "status": "healthy",
            "environment": app.config.get("ENV", "unknown"),
            "database": db_status,
        })

    @app.route("/ping")
    def ping():
        """Simple ping endpoint"""
        return jsonify({"status": "ok", "message": "pong"})