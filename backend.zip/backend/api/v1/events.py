from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import Event, EventAttendee
from backend.extensions import db
from .utils import success_response, error_response
from datetime import datetime

# ✅ Use url_prefix without trailing slash
events_bp = Blueprint("events", __name__, url_prefix="/events")


# ✅ GET /api/v1/events
@events_bp.route("", methods=["GET"])
def list_events():
    page = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 20))

    events = (
        Event.query.order_by(Event.start_time.desc())
        .paginate(page=page, per_page=per_page, error_out=False)
    )

    return success_response([e.to_dict() for e in events.items])


# ✅ GET /api/v1/events/<event_id>
@events_bp.route("/<int:event_id>", methods=["GET"])
def get_event(event_id: int):
    event = Event.query.get_or_404(event_id)
    return success_response(event.to_dict())


# ✅ POST /api/v1/events
@events_bp.route("", methods=["POST"])
@jwt_required()
def create_event():
    user_id = get_jwt_identity()
    data = request.get_json()

    try:
        event = Event(
            user_id=user_id,
            title=data["title"],
            description=data["description"],
            event_type=data["event_type"],
            start_time=datetime.fromisoformat(data["start_time"]),
            end_time=datetime.fromisoformat(data["end_time"]),
            location=data.get("location"),
            is_virtual=data.get("is_virtual", False),
        )
        db.session.add(event)
        db.session.commit()
        return success_response(event.to_dict(), "Event created", 201)
    except Exception as e:
        db.session.rollback()
        return error_response(f"Failed to create event: {str(e)}", 400)


# ✅ PATCH /api/v1/events/<event_id>
@events_bp.route("/<int:event_id>", methods=["PATCH"])
@jwt_required()
def update_event(event_id: int):
    event = Event.query.get_or_404(event_id)
    data = request.get_json()

    try:
        for key in [
            "title",
            "description",
            "event_type",
            "start_time",
            "end_time",
            "location",
            "is_virtual",
        ]:
            if key in data:
                # Handle datetime parsing if needed
                if key in ["start_time", "end_time"]:
                    setattr(event, key, datetime.fromisoformat(data[key]))
                else:
                    setattr(event, key, data[key])

        event.updated_at = datetime.utcnow()
        db.session.commit()
        return success_response(event.to_dict(), "Event updated")
    except Exception as e:
        db.session.rollback()
        return error_response(f"Failed to update event: {str(e)}", 400)


# ✅ DELETE /api/v1/events/<event_id>
@events_bp.route("/<int:event_id>", methods=["DELETE"])
@jwt_required()
def delete_event(event_id: int):
    event = Event.query.get_or_404(event_id)
    try:
        db.session.delete(event)
        db.session.commit()
        return success_response(message="Event deleted")
    except Exception as e:
        db.session.rollback()
        return error_response(f"Failed to delete event: {str(e)}", 400)


# ✅ POST /api/v1/events/<event_id>/register
@events_bp.route("/<int:event_id>/register", methods=["POST"])
@jwt_required()
def register_event(event_id: int):
    user_id = get_jwt_identity()
    event = Event.query.get_or_404(event_id)

    try:
        attendee = EventAttendee(user_id=user_id, event_id=event_id)
        db.session.add(attendee)
        db.session.commit()
        return success_response(event.to_dict(), "Registered for event", 201)
    except Exception as e:
        db.session.rollback()
        return error_response(f"Failed to register: {str(e)}", 400)
