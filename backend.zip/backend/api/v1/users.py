from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import User
from backend.extensions import db
from .utils import success_response, error_response

users_bp = Blueprint("users", __name__, url_prefix="/users")

@users_bp.route("/", methods=["GET"])
@jwt_required()
def list_users():
    page = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 20))
    users = User.query.paginate(page, per_page, error_out=False)
    return success_response([u.to_dict(exclude=["password_hash"]) for u in users.items])

@users_bp.route("/<int:user_id>", methods=["GET"])
@jwt_required()
def get_user(user_id: int):
    user = User.query.get_or_404(user_id)
    return success_response(user.to_dict(exclude=["password_hash"]))

@users_bp.route("/<int:user_id>", methods=["PATCH"])
@jwt_required()
def update_user(user_id: int):
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    for key in ["username", "email"]:
        if key in data:
            setattr(user, key, data[key])
    db.session.commit()
    return success_response(user.to_dict(exclude=["password_hash"]), "User updated")

@users_bp.route("/<int:user_id>", methods=["DELETE"])
@jwt_required()
def delete_user(user_id: int):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return success_response(message="User deleted")

@users_bp.route("/me", methods=["GET"])
@jwt_required()
def get_me():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)
    return success_response(user.to_dict(exclude=["password_hash"]))
