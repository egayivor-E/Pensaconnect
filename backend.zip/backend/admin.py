from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask import g
from backend.extensions import db
import backend.models as models
from wtforms import Form, fields as wtfields, validators
from flask_admin.contrib.sqla.fields import QuerySelectField
from wtforms.fields.core import UnboundField
from wtforms.fields import StringField, PasswordField, SelectField, DateField, TextAreaField
import sys # For debugging print


# 🔒 Custom ModelView with CSP nonce support
class AdminBaseForm(Form):
    """
    Base Form class used to prevent WTForms tuple bug on certain SQLAlchemy/WTForms versions.
    We set skip_default_prefix=True to bypass some of the problematic introspection.
    """
    skip_default_prefix = True


class SecureModelView(ModelView):
    """
    Secure base ModelView that fixes the 'tuple has no attribute items' bug
    and injects a CSP nonce into admin templates.
    """

    form_base_class = AdminBaseForm 
    can_view_details = True
    can_export = True
    page_size = 50

    form_args = {
        'id': {'label': 'ID', 'render_kw': {'readonly': True}},
        # **CORE FIX:** Explicitly setting validators to [] suppresses the automatic creation
        # of validators (UniqueConstraint, relationships) that cause the 'tuple' object error.
        
        # Fixes for User model unique fields:
        'username': {'validators': []},
        'email': {'validators': []},
        
        # NEW FIXES: Targeting common Foreign Key/Relationship fields (like in StudyPlanProgress)
        # These are commonly converted to QuerySelectField, which triggers the bug.
        'roles': {'validators': []}, # For User model's many-to-many relationship
        'user_id': {'validators': []}, # Common foreign key field name
        'study_plan_id': {'validators': []}, # Common foreign key field name for StudyPlanProgress
    }
    
    form_overrides = {
        'QuerySelectField': QuerySelectField
    }
    
    # Exclude complex collection fields that should never be edited via the parent form
    form_excluded_columns = ('group_members', 'posts', 'comments', 'replies', 'messages_sent',
                             'threads', 'likes', 'bookmarks', 'notifications', 
                             'activities', 'resources', 'archive', 'roles', 
                             'study_plans', 'progress', 'attendees', 'reminders',
                             'donations', 'notifications_received', 'testimonies',
                             'group_chats_created', 'thread_likes', 'thread_comments',
                             'post_likes', 'testimony_likes', 'testimony_comments',
                             'created_by', 'creator_user', 'users', 'members' # General exclusions
                            )


    def render(self, template, **kwargs):
        kwargs["csp_nonce"] = getattr(g, "csp_nonce", "")
        return super().render(template, **kwargs)

    def scaffold_form(self):
        """
        Build the form class and sanitize field flags to avoid the WTForms tuple bug.
        This manual fix is kept as a last-resort safeguard, though the form_args fix 
        should prevent the crash from happening before this point.
        """
        try:
            # The crash typically happens inside this super call during introspection
            form_class = super().scaffold_form()
        except Exception as e:
            # If scaffolding fails, print the error for diagnostics and re-raise.
            print(f"ERROR: Scaffold form failed before manual fix attempt: {e}", file=sys.stderr)
            raise 

        
        # This manual fix remains as a safeguard for any model/field not covered by form_args
        for name, field in form_class.__dict__.items():
            if isinstance(field, UnboundField):
                
                # Check 1: Fix flags directly on the UnboundField itself
                if hasattr(field, "flags") and isinstance(field.flags, tuple):
                    flag_dict = {flag: True for flag in field.flags}
                    field.flags = flag_dict
                    print(f"DEBUG_FIX: Corrected UnboundField flags for {self.model.__name__}.{name}")
                    
                # Check 2: Fix flags on the validators (field.args[0] should be the validators list)
                if field.args and isinstance(field.args[0], (list, tuple)):
                    validators_list = list(field.args[0])
                    new_validators = []
                    fix_applied = False
                    
                    for validator in validators_list:
                        if hasattr(validator, 'field_flags') and isinstance(validator.field_flags, tuple):
                            validator.field_flags = {flag: True for flag in validator.field_flags}
                            fix_applied = True
                            print(f"DEBUG_FIX: Corrected validator flags for {self.model.__name__}.{name}")
                            
                        new_validators.append(validator)

                    if fix_applied:
                        field.args = (new_validators,) + field.args[1:]

        return form_class


def register_admin(app):
    """Register all models in Flask-Admin with security enhancements"""
    admin = Admin(app, name="PensaConnect Admin", template_mode="bootstrap4")

    # Loop through all attributes in models.py and register models
    for name in dir(models):
        cls = getattr(models, name)
        
        if (
            isinstance(cls, type) 
            and issubclass(cls, db.Model) 
            and cls is not db.Model
        ):
            is_abstract = hasattr(cls, '__abstract__') and cls.__abstract__
            has_table = hasattr(cls, '__table__') or hasattr(cls, '__tablename__')
            
            if is_abstract and not has_table:
                print(f"⚠️ Could not register {name}: Abstract Base Model skipped")
                continue
            
            # Use the global SecureModelView for all models
            view = SecureModelView(cls, db.session)
            view_name = 'SecureModelView'

            try:
                admin.add_view(view)
                print(f"✅ Registered {name} in Flask-Admin ({view_name})")
            except Exception as e:
                print(f"⚠️ Could not register {name}: {e}")

    return admin