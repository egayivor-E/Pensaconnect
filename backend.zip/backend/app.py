# backend/app.py
try:
    import sqlalchemy_fix  # Apply SQLAlchemy compatibility patch if needed
except ImportError as e:
    print(f"Note: SQLAlchemy patch not applied: {e}")

import os
from backend import create_app
from backend.config import config

# Pick config dynamically (default: development)
env = os.getenv("FLASK_ENV", "development")
app = create_app(config[env])

# Gunicorn / uWSGI entrypoint
if __name__ == "__main__":
    port = int(app.config.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=app.config["DEBUG"])

# REMOVE the duplicate route below - it's already handled in __init__.py
# @app.route("/")
# def index():
#     return {"status": "ok", "message": "PensaConnect Backend is running 🎉"}, 200